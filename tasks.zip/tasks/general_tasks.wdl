version 1.0
# LICENSE
#   Copyright 2022 Ultima Genomics
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
# DESCRIPTION
#   Tasks used in multiple workflows, edited version (GSI OICR)
#
# OICR NOTICE: Multiple tasks were modified to use docker containers via Apptainer (former Singularity) developed by Berkeley National Lab
# Some of the tasks were switched to use modules rather than docker containers
# Other optimizations were introduced to make the code work in SLURM cluster environment
import "structs.wdl" as Structs

task ExtractSampleNameFlowOrder{
    input{
        File input_cram
        File monitoring_script
        String modules = "gatk/4.6.2.0"
        References references
        Int threads = 1
        Int jobMemory = 2
        Int timeout = 4
    }

    parameter_meta {
      input_cram: "input cram file"
      monitoring_script: "Path to monitoring script"
      modules: "Used modules"
      references: "Reference resources"
      threads: "Number of CPUs to use"
      jobMemory: "Allocated RAM in Gigs"
      timeout: "Timeout in Hours"
    }

    command <<<
        set -ex
        set -xo pipefail

        bash ~{monitoring_script} | tee monitoring.log >&2 &
        
        gatk GetSampleName  \
            -I ~{input_cram} \
            -R ~{references.ref_fasta} \
            -O sample_name.tmp.txt
        sort sample_name.tmp.txt | uniq > sample_name.txt

        #if there is more than a single sample name, fail
        if [[ $(wc -l < sample_name.txt) -ne 1 ]]
        then
            echo "Error: more than one sample name found in the input BAM file" >&2
            exit 1
        fi

        gatk ViewSam -I ~{input_cram} \
                --HEADER_ONLY true --ALIGNMENT_STATUS All --PF_STATUS All \
                | grep "^@RG" | awk '{for (i=1;i<=NF;i++){if ($i ~/FO:/) {print substr($i,4,4)}}}' | sed '1!d' \
                > flow_order.txt

        gatk ViewSam -I ~{input_cram} \
                --HEADER_ONLY true --ALIGNMENT_STATUS All --PF_STATUS All \
                | grep "^@RG" | awk '{for (i=1;i<=NF;i++){if ($i ~/BC:/) {print substr($i,4)}}}' | sed '1!d' \
                > barcode.txt

        gatk ViewSam -I ~{input_cram} \
                --HEADER_ONLY true --ALIGNMENT_STATUS All --PF_STATUS All \
                | grep "^@RG" | awk '{for (i=1;i<=NF;i++){if ($i ~/ID:/) {print substr($i,4)}}}' | sed '1!d' \
                > id.txt
    >>>

    runtime {
        memory:  "~{jobMemory} GB"
        modules: "~{modules}"
        cpu:     "~{threads}"
        timeout: "~{timeout}"
    }

    output {
        String sample_name = read_string("sample_name.txt")
        String flow_order = read_string("flow_order.txt")
        String barcode_seq = read_string("barcode.txt")
        String readgroup_id = read_string("id.txt")
        File sample_name_file = "sample_name.txt"
        File flow_order_file = "flow_order.txt"
        File barcode_seq_file = "barcode.txt"
        File readgroup_id_file = "id.txt"
        File monitoring_log = "monitoring.log"
    }
}

# only works with simple maps (two columns)
task MakeStringMap {
    input {
        Array[String] keys
        Array[String] values
        String docker
        Int jobMemory = 2
        Int timeout = 2
    }

    parameter_meta {
      keys: "input keys for mapping"
      values: "input values for mapping"
      docker: "docker, we are not using it for this task in GSI version"
      jobMemory: "Allocated RAM in Gigs"
      timeout: "Timeout in Hours"
    }

    String results_path = "results.tsv"
    command <<<
        cat ~{write_tsv(transpose([keys,values]))} > ~{results_path}
    >>>
    runtime {
      memory:  "~{jobMemory} GB"
      timeout: "~{timeout}"
    }
    output {
        Map[String, String] map = read_map(results_path)
    }
}


# Aggregate picard metrics and coverage and variant calling reports into one h5 and convert h5 to json
# This tasks may not be called from any of the other places
task AggregateMetricsAndConvertToJson {
    input {
        File monitoring_script
        Array[File]? picard_files
        String base_file_name
        File? coverage_all_h5
        File? short_report_h5
        File? extended_report_h5
        File? no_gt_report_h5
        Float? contamination_stdout
        String docker
        String modules = "apptainer/1.4.5"
        Int jobMemory = 2
        Int timeout = 2
        Int preemptible_tries
        Boolean no_address
    }

    parameter_meta {
      picard_files: "Array of picard files"
      monitoring_script: "Path to monitoring script"
      preemptible_tries: "Preemptible tries: integer, not in use in GSI version"
      base_file_name: "basename for the output file"
      coverage_all_h5: "coverage, optional input"
      short_report_h5: "short report, optional"
      extended_report_h5: "optional extended report"
      no_gt_report_h5: "No GT report, optional"
      contamination_stdout: "contamination metrics"
      docker: "docker, we are not using it for this task in GSI version"
      modules: "Used modules"
      no_address: "Flag which is not in use in GSI version"
      jobMemory: "Allocated RAM in Gigs"
      timeout: "Timeout in Hours"
    }

    command <<<
    set -xeo pipefail
    bash ~{monitoring_script} | tee monitoring.log >&2 &

    export APPTAINER_TMPDIR=/tmp
    apptainer exec \
      --bind ${PWD}:${PWD} \
      ~{docker} \
    collect_existing_metrics \
        ~{true="--metric_files " false="" defined(picard_files)} ~{ sep=' ' picard_files} \
        ~{"--coverage_h5 " + coverage_all_h5} \
        ~{"--short_report_h5 " + short_report_h5} \
        ~{"--extended_report_h5 " + extended_report_h5} \
        ~{"--no_gt_report_h5 " + no_gt_report_h5} \
        ~{"--contamination_stdout " + contamination_stdout} \
        --output_h5 ~{base_file_name}.aggregated_metrics.h5
   
   apptainer exec \
     --bind ${PWD}:${PWD} \
     ~{docker} \
    convert_h5_to_json \
            --root_element "metrics" \
            --ignored_h5_key_substring histogram \
            --input_h5 ~{base_file_name}.aggregated_metrics.h5 \
            --output_json ~{base_file_name}.aggregated_metrics.json
    >>>

    runtime {
        memory: "~{jobMemory} GB"
        modules: "~{modules}"
        timeout: "~{timeout}"
    }
    output {
        File monitoring_log = "monitoring.log"
        File aggregated_metrics_h5 = "~{base_file_name}.aggregated_metrics.h5"
        File aggregated_metrics_json = "~{base_file_name}.aggregated_metrics.json"
    }
}

task ConvertSorterStatsToH5 {
    input {
        File monitoring_script
        Int? file_name_suffix

        # runtime arguments
        Int disk_size = 20
        Int preemptible_tries
        String docker
        Boolean no_address

        # sorter_to_h5 args
        File input_csv_file
        File input_json_file
    }
    
    String input_basename = basename(input_csv_file, ".csv")
    String suffix = if defined(file_name_suffix) then ".~{file_name_suffix}" else ""
    String aggregated_metrics_h5_file = "~{input_basename}~{suffix}.aggregated_metrics.h5"
    String aggregated_metrics_json_file = "~{input_basename}~{suffix}.aggregated_metrics.json"
    
    command <<<
        set -xeo pipefail
        bash ~{monitoring_script} | tee monitoring.log >&2 &
        export HDF5_USE_FILE_LOCKING=FALSE #to prevent unable to lock file, errno = 11, error message = 'Resource temporarily unavailable' errors

        sorter_to_h5 \
            --input_csv_file "~{input_csv_file}" \
            --input_json_file "~{input_json_file}" \
            --output_h5_file "~{aggregated_metrics_h5_file}"

        convert_h5_to_json \
            --root_element "metrics" \
            --ignored_h5_key_substring histogram \
            --input_h5 "~{aggregated_metrics_h5_file}" \
            --output_json "~{aggregated_metrics_json_file}"

    >>>
    runtime {
        preemptible: preemptible_tries
        memory: "2 GB"
        disks: "local-disk " + disk_size + " HDD"
        docker: docker
        noAddress: no_address
        maxRetries: 1
    }
    output {
        File monitoring_log = "monitoring.log"
        File aggregated_metrics_h5 = "~{aggregated_metrics_h5_file}"
        File aggregated_metrics_json = "~{aggregated_metrics_json_file}"
    }
}

task ScatterIntervalList {
    input {
        File monitoring_script
        File interval_list
        Int scatter_count
        Int break_bands_at_multiples_of
        Int jobMemory = 6
        String modules = "gatk/4.6.2.0"
        String dummy_input_for_call_caching 
        Boolean? convert_to_bed = false
    }
    parameter_meta {
        convert_to_bed: {
            help: "If true, convert interval_list files to BED format in addition to interval_list format",
            type: "Boolean",
            category: "input_optional"
        }
    }
    command <<<
    bash ~{monitoring_script} | tee monitoring.log >&2 &
    echo ~{dummy_input_for_call_caching}
    set -xeo pipefail
    mkdir out
    gatk --java-options '-Xms4g' \
      IntervalListTools \
      SCATTER_COUNT=~{scatter_count} \
      SUBDIVISION_MODE=BALANCING_WITHOUT_INTERVAL_SUBDIVISION_WITH_OVERFLOW \
      UNIQUE=true \
      SORT=true \
      BREAK_BANDS_AT_MULTIPLES_OF=~{break_bands_at_multiples_of} \
      INPUT=~{interval_list} \
      OUTPUT=out

    python3 <<CODE
    import glob, os
    # Works around a JES limitation where multiples files with the same name overwrite each other when globbed
    intervals = sorted(glob.glob("out/*/*.interval_list"))
    for i, interval in enumerate(intervals):
      (directory, filename) = os.path.split(interval)
      newName = os.path.join(directory, str(i+1).rjust(len(str(len(intervals))),"0") + filename)
      os.rename(interval, newName)
    with open("interval_count.txt", "w") as fh:
        fh.write(str(len(intervals)))
    CODE

    if [[ "~{select_first([convert_to_bed, false])}" == "true" ]]; then
      for file in out/*/*.interval_list; do
        bed_file="${file%.interval_list}.bed"
        grep -v @ "$file" | awk 'BEGIN{OFS="\t"}{print $1,$2-1,$3}' > "$bed_file"
      done
    fi
    
    >>>
    output {
        Array[File] out = glob("out/*/*.interval_list")
        Int interval_count = read_int('interval_count.txt')
        Array[File]? out_bed = glob("out/*/*.bed")
        File monitoring_log = "monitoring.log"
    }
    runtime {
        memory: "~{jobMemory} GB"
        modules: "~{modules}"
    }
}

task IntervalListOfGenome {
  input  {
    File ref_fai
    File ref_dict
    String docker
    Int disk_size
    Int preemptible_tries
    Boolean no_address
    File monitoring_script
  }
  command <<<
    set -xe
    bash ~{monitoring_script} | tee monitoring.log >&2 &

    grep -v '[ME_-]' ~{ref_fai} | awk '{print $1"\t"1"\t"$2"\t+\t."}' > modifai
    cat ~{ref_dict} modifai > genome.interval_list
  >>>

  runtime {
    preemptible: preemptible_tries
    cpu: "1"
    memory: "1 GB"
    disks: "local-disk " + disk_size + " HDD"
    docker: docker
    continueOnReturnCode: true
    maxRetries: 1
    noAddress: no_address
  }
  output{
    File monitoring_log = "monitoring.log"
    File interval_list = "genome.interval_list"
  }
}


task IntervalListFromString {
  input  {
    String intervals_string
    File ref_fai
    File ref_dict
    Int jobMemory = 2
    Int timeout = 2
    File monitoring_script
  }
  command <<<
    set -xe
    bash ~{monitoring_script} | tee monitoring.log >&2 &

    echo "~{intervals_string}" | tr ':-' '\t\t' | sed 's/;/\n/g' | awk '{print $0 "\t+\t. intersection ACGTmer.1"}' > interval.tsv
    cat ~{ref_dict} interval.tsv > intervals.interval_list
  >>>
  runtime {
    memory: "~{jobMemory} GB"
    continueOnReturnCode: true
  }
  output{
    File monitoring_log = "monitoring.log"
    File interval_list = "intervals.interval_list"
  }
}


task IntervalListTotalLength {
  input {
    File interval_list
    File monitoring_script
    Int jobMemory = 1
    Int timeout = 1
  }
   command <<<
    set -xe
    bash ~{monitoring_script} | tee monitoring.log >&2 &
    grep -v @ ~{interval_list} | awk '{sum+=$3-$2}; END {printf "%0.f\n", sum}' > sum.txt
    cat sum.txt
  >>>

  output {
    Float interval_list_length = read_float('sum.txt')
    File monitoring_log = "monitoring.log"
  }

   runtime {
    memory: "~{jobMemory} GB"
    timeout: "~{timeout}"
  }
}

task FastaLengthFromIndex {
  input {
    File fasta_index
    File monitoring_script
    Int jobMemory = 2
    Int timeout = 2
  }
   command <<<
     set -xe
     bash ~{monitoring_script} >&2 &
     awk '{sum+=$2} END {printf "%0.f\n", sum}' ~{fasta_index} > sum.txt
  >>>

  output {
    Float fasta_length = read_float('sum.txt')
  }

   runtime {
    memory: "~{jobMemory} GB"
    timeout: "~{timeout}"
  }
}

task ConcatMetricsJsons {
    input {
        File monitoring_script
        Array[File] jsons
        String base_file_name
        String docker
        Int preemptible_tries
        Boolean no_address
        Int disk_size = 20
    }

    command <<<
    set -xeo pipefail

    bash ~{monitoring_script} | tee monitoring.log >&2 &

    echo ~{sep=',' jsons} > json_files.txt

    python <<CODE
    import json

    json_out = {'metrics': {}}
    with open('json_files.txt') as file_handler:
        json_files = file_handler.read().rstrip().split(',')
    for jf in json_files:
        with open(jf) as file_handler:
            json_content = json.load(file_handler)
        if "metrics" not in json_content:
            raise ValueError(f"Invalid json file {jf} - does not contain a 'metrics' key")
        joint_keys = set(json_content["metrics"]).intersection(set(json_out["metrics"]))
        if len(joint_keys) > 0:
            raise ValueError(f"Encountered duplicate metrics - {joint_keys}")
        json_out['metrics'].update(json_content['metrics'])
    with open('~{base_file_name}.aggregated_metrics.json','w') as file_handler:
        json.dump(json_out, file_handler, indent=2)
    CODE

    >>>
    runtime {
        preemptible: preemptible_tries
        memory: "1 GB"
        disks: "local-disk " + disk_size + " HDD"
        docker: docker
        noAddress: no_address
    }
    output {
        File monitoring_log = "monitoring.log"
        File aggregated_metrics_json = "~{base_file_name}.aggregated_metrics.json"
    }
}

task DownsampleCramBam {
    input {
        String base_file_name
        File input_cram_bam
        File? input_cram_bam_index
        Float downsample_frac
        File? target_regions_bed
        Int? seed 
        String output_format = "cram"
        References references
        File monitoring_script
        String docker
        String modules = "samtools/1.14"
        Int preemptibles
        Int disk_size = ceil((1.1+(downsample_frac*4))*size(input_cram_bam,"GB") + 20)
        Int cpus = 16
        Int memory_gb = 1
    }
    String output_format_flag = if output_format == "cram" then "-C" else "-b"
    String output_format_extension = if output_format == "cram" then ".cram" else ".bam"
    String output_index_format_extension = if output_format == "cram" then ".crai" else ".bai"
    String output_cram_bam_name = base_file_name + output_format_extension
    
    command <<<
        set -xeo pipefail

        bash ~{monitoring_script} | tee monitoring.log >&2 &

        if ~{defined(seed)}
        then
            seed_var="~{seed}"
        else
            seed_var=$RANDOM
        fi
        echo "Seed used " $seed_var
        echo $seed_var >> downsampling_seed.txt

        samtools view \
          -s ${seed_var}~{downsample_frac} \
          ~{output_format_flag} \
          -T ~{references.ref_fasta} \
          ~{if defined(target_regions_bed) then "--regions-file ~{target_regions_bed}" else ""} \
          -o ~{output_cram_bam_name} \
          --threads ~{cpus} \
          ~{input_cram_bam}

        samtools index ~{output_cram_bam_name}
    >>>
    runtime {
        disks: "local-disk " + disk_size + " HDD"
        cpu: "~{cpus}"
        memory: "~{memory_gb} GB"
        preemptible: preemptibles
        modules: "~{modules}"
        docker: docker
        noAddress: false
    }
    output {
        File output_cram_bam = "~{output_cram_bam_name}"
        File output_cram_bam_index = "~{output_cram_bam_name}~{output_index_format_extension}"
        File downsampling_seed = "downsampling_seed.txt"
        File monitoring_log = "monitoring.log"
    }
}

task ToFastq {
    input {
        File input_cram
        String base_file_name
        References references
        File monitoring_script
        String docker
        String modules = "samoools/1.14"
        Boolean no_address
        Int preemptibles
        Int disk_size = ceil(3*size(input_cram,"GB") + 20)
    }
    String output_fq_name = base_file_name + ".fq.gz"
    command <<<
        set -xeo pipefail

        bash ~{monitoring_script} | tee monitoring.log >&2 &

        samtools fastq \
          --reference ~{references.ref_fasta}\
          -F 0x900 \
          -0 ~{output_fq_name} \
          --threads 2 \
          ~{input_cram}
    >>>
    runtime {
        disks: "local-disk " + disk_size + " HDD"
        cpu: 2
        memory: "1 GB"
        preemptible: preemptibles
        modules: "~{modules}"
        docker: docker
        noAddress: no_address
    }
    output {
        File output_fastq = "~{output_fq_name}"
        File monitoring_log = "monitoring.log"
    }
}

task ConcatHtmls {
   input {
        # input for concat
        Array[File] htmls

        # call arguments
        File monitoring_script
        String base_file_name

        # runtime arguments
        Int preemptible_tries
        String docker
        Int disk_size = ceil(2*size(htmls,"GB") + 1)



    }
    command <<<
        set -xeo pipefail

        start=$(date +%s)

        bash ~{monitoring_script} | tee monitoring.log >&2 &

        echo ~{sep=',' htmls} > htmls_files.txt
        ls -lstr
        cat htmls_files.txt

        i=1
        i=1; for file in $(cat htmls_files.txt| sed "s/,/ /g"); do cp "$file" "$i.html" ;
        cat $i.html >> ~{base_file_name}_aggregated.html; rm $i.html ;i=$((i + 1)) ; done

        ls -lstr
        echo "**************** D O N E ****************"

        end=$(date +%s)
        mins_elapsed=$(( (end - start) / 60))
        secs_elapsed=$(( (end - start) % 60 ))
        if [ $secs_elapsed -lt 10 ]; then
            secs_elapsed=0$secs_elapsed
        fi
        echo "Total run time: $mins_elapsed:$secs_elapsed"
        ls -ltrsa

    >>>
    runtime {
        preemptible: preemptible_tries
        memory: "2 GB"
        docker: docker
        cpu: "1"
        disks: "local-disk " + ceil(disk_size) + " HDD"
        noAddress: true
    }

    output {
        File report_html = "~{base_file_name}_aggregated.html"
        File monitoring_log = "monitoring.log"
    }
}

task ZipAndIndexVcf{
    input{
        File input_vcf
        File monitoring_script
        String docker
        String modules = "bcftools/1.9"
        Boolean no_address
        Int preemptibles
        Int disk_size = ceil(2*size(input_vcf,"GB")+20)
    }
    String output_vcf = basename(input_vcf) + ".gz"
    command <<<
        set -xeo pipefail
        bash ~{monitoring_script} | tee monitoring.log >&2 &

        bcftools view -O z -o ~{output_vcf} ~{input_vcf}
        bcftools index -t ~{output_vcf}
    >>>
    runtime {
        disks: "local-disk " + disk_size + " HDD"
        cpu: 4
        memory: "2 GB"
        preemptible: preemptibles
        docker: docker
        modules: "~{modules}"
        noAddress: no_address
    }
    output {
        File output_vcf_file = "~{output_vcf}"
        File output_vcf_index_file = "~{output_vcf}.tbi"
        File monitoring_log = "monitoring.log"
    }
}


task RenameSampleInBam {
    input{
        File monitoring_script
        File input_cram_bam
        File input_cram_bam_index
        String name
        String docker
        String modules = "samtools/1.14"
        Int disk_size = ceil(2*size(input_cram_bam, "GB"))+20
        Int preemptible_tries
        Int cpus=1
        Boolean no_address
    }
    String detect_input_ending = if sub(input_cram_bam, ".*\\.cram$", "is_cram") == "is_cram" then "is_cram" else "is_bam"
    String extension = if detect_input_ending=="is_cram" then ".cram" else ".bam"
    String extension_index = if detect_input_ending=="is_cram" then ".crai" else ".bai"
    String basename = basename(input_cram_bam, extension)
    command <<<
        bash ~{monitoring_script} | tee monitoring.log >&2 &
        set -xeo pipefail
        samtools view -H ~{input_cram_bam} -@ ~{cpus} | sed "s/SM:[^\t]*/SM:~{name}/g" | samtools reheader - ~{input_cram_bam} > ~{basename}~{extension}
        samtools index ~{basename}~{extension}
    >>>
    runtime {
        preemptible: preemptible_tries
        memory: "2 GB"
        cpu: "1"
        disks: "local-disk " + disk_size + " LOCAL"
        docker: docker
        modules: "~{modules}"
        noAddress: no_address
        maxRetries: 1
    }
    output {
        File monitoring_log = "monitoring.log"
        File output_bam = "~{basename}~{extension}"
        File output_bam_index = "~{basename}~{extension}~{extension_index}"
    }
}

task MergeCramFiles {
    input {
            File monitoring_script
            String output_base_name
            String sample_name
            Array[File] crams
            References references
            File? cache_tarball
            String docker
            String modules = "samtools/1.14"
            Boolean no_address
            Int? cpus
            Int preemptible_tries
    }
    String output_cram_name = "~{output_base_name}.cram"
    Int cpus_to_use = select_first([cpus, ceil(size(crams, "GB") / 10)])
    command <<<
            bash ~{monitoring_script} | tee monitoring.log >&2 &

            ~{"tar -zxf "+cache_tarball}

            REF_CACHE=cache/%2s/%2s/ REF_PATH='.' samtools merge -@ ~{cpus_to_use} --reference ~{references.ref_fasta} - ~{sep=" " crams} | \
                samtools reheader - --command 'sed "s/SM:[^\t]*/SM:~{sample_name}/g"' | \
                samtools view -h - -@ ~{cpus_to_use} -C --reference ~{references.ref_fasta} -o ~{output_cram_name} --output-fmt-option embed_ref
            samtools index ~{output_cram_name}
    >>>
    output {
            File monitoring_log = "monitoring.log"
            File output_cram = "~{output_cram_name}"
            File output_cram_index = "~{output_cram_name}.crai"
    }
    runtime {
            memory: "8GB"
            disks: "local-disk " + (ceil(size(cache_tarball, "GB") + size(crams, "GB")) * 3 + 10) + " HDD"
            docker: docker
            modules: "~{modules}"
            noAddress: no_address
            cpu: "~{cpus_to_use}"
            preemptible: preemptible_tries

    }
}

task MergeBams {
    input {
        File monitoring_script
        Array[File] inputs
        String output_prefix
        String docker
        String modules = "samtools/1.14"
        Int disk_size = ceil(2*size(inputs, "GB")) + 20
        Int preemptible_tries
        Boolean no_address
    }
    command<<<
        set -xeo pipefail
        bash ~{monitoring_script} > monitoring.log &
        samtools merge -c -@ 8 ~{output_prefix}.bam ~{sep=' ' inputs}
        samtools index ~{output_prefix}.bam
    >>>
    runtime {
        preemptible: preemptible_tries
        memory: "16 GB"
        cpu: "8"
        disks: "local-disk " + disk_size + " LOCAL"
        docker: docker
        modules: "~{modules}"
        noAddress: no_address
        maxRetries: 1
    }
    output {
        File monitoring_log = "monitoring.log"
        File output_bam = "~{output_prefix}.bam"
        File output_bam_index = "~{output_prefix}.bam.bai"
    }
}

task MergeVCFs {
  input {
    File monitoring_script
    Array[File] input_vcfs
    Array[File] input_vcfs_indexes
    String output_vcf_name
    Int disk_size = ceil(2*size(input_vcfs,"GB")+5)
    Int preemptible_tries
    String docker
    String modules = "gatk/4.6.2.0"
    Boolean no_address
  }
  # Using MergeVcfs instead of GatherVcfs so we can create indices
  # See https://github.com/broadinstitute/picard/issues/789 for relevant GatherVcfs ticket
  command {
    bash ~{monitoring_script} | tee monitoring.log >&2 &
    set -xeo pipefail
    gatk --java-options '-Xms9000m' \
      MergeVcfs \
      INPUT=~{sep=' INPUT=' input_vcfs} \
      OUTPUT=~{output_vcf_name}
  }
  runtime {
    preemptible: preemptible_tries
    memory: "10 GB"
    disks: "local-disk " + disk_size + " HDD"
    docker: docker
    modules: "~{modules}"
    noAddress: no_address
    maxRetries: 1
  }
  output {
    File output_vcf = "~{output_vcf_name}"
    File output_vcf_index = "~{output_vcf_name}.tbi"
    File monitoring_log = "monitoring.log"
  }
}

task ConcatVcfs{
    input {
        File monitoring_script
        Array[File] input_vcfs
        Array[File] input_vcfs_indexes
        String output_vcf_name
        Int disk_size = ceil(2*size(input_vcfs,"GB")+5)
        Int preemptible_tries
        String docker
        String modules = "bcftools/1.19"
        Boolean no_address
    }
    command {
        bash ~{monitoring_script} | tee monitoring.log >&2 &
        set -xeo pipefail
        bcftools concat ~{sep=' ' input_vcfs} | bcftools sort -T . -Oz -o ~{output_vcf_name} - 
        bcftools index -t ~{output_vcf_name}
    }
    runtime {
        preemptible: preemptible_tries
        memory: "4 GB"
        disks: "local-disk " + disk_size + " HDD"
        docker: docker
        modules: "~{modules}"
        noAddress: no_address
        maxRetries: 2
    }
    output {
        File output_vcf = "~{output_vcf_name}"
        File output_vcf_index = "~{output_vcf_name}.tbi"
        File monitoring_log = "monitoring.log"
    }
}

task FilterVcfWithBcftools {
    input {
        String docker
        String? base_file_name
        File monitoring_script
        File input_vcf
        String? bcftools_extra_args
        Array[File]? exclude_regions
        Array[File]? include_regions
        String modules = "bcftools/1.9"
        Int preemptible_tries = 1
        Int disk_size = ceil((size(input_vcf, "GB") * 3 + size(select_first([include_regions, []]), "GB") + size(select_first([exclude_regions, []]), "GB")) * 2 + 10)
        Int memory_gb = 4 + ceil(ceil(size(select_first([include_regions, []]), "GB") + size(select_first([exclude_regions, []]), "GB")) * 0.25)
        Int cpus = 4
    }
        String output_base_name = select_first([base_file_name, basename(input_vcf, ".vcf.gz")])
        String output_vcf_filename = output_base_name + ".filtered.vcf.gz"
    
    meta {
        description : "Filter input vcf file using bcftools, with 'bcftools view' args and with genomic regions to include and/or exclude."
        author: "Ultima Genomics"
        WDL_AID: { exclude: [
            "preemptible_tries"
        ]}
    }
    parameter_meta {
        docker: {
            help: "Docker image to use for this task, must be able to run 'bcftools' with no preceding commands.",
            type: "String",
            category: "input_required"
        }
        base_file_name: {
            help: "Base file name for output files.",
            type: "String", 
            category: "input_optional"
        }
        input_vcf: {
            help: "Input vcf file. Note that an index is not needed.",
            type: "File",
            category: "input_required"
        }
        bcftools_extra_args: {
            help: "Extra arguments to pass to bcftools view. For example, use '-f PASS' to only include variants with a PASS filter.",
            type: "String",
            category: "input_optional"
        }
        exclude_regions: {
            help: "Regions to exclude from the output vcf. Supported formats are bed, bed.gz, vcf, vcf.gz. VCF exclusion is done using bcftools view -T ^regions, by position and not by ref and alt.",
            type: "Array[File]",
            category: "input_optional"
        }
        include_regions: {
            help: "Regions to include in the output vcf. Supported formats are bed, bed.gz. Inclusion is done using 'bcftools view -T'.",
            type: "Array[File]",
            category: "input_optional"
        }
        preemptible_tries: {
            help: "Number of times to retry this task if it fails.",
            type: "Int",
            category: "input_optional"
        }
        disk_size: {
            help: "Size of the local disk to use for this task, in GB. By default it is calculated from the input file sizes.",
            type: "Float",
            category: "input_optional"
        }
        memory_gb: {
            help: "Amount of memory to use for this task, in GB. Default is 4 (GB).",
            type: "Int",
            category: "input_optional"
        }
        cpus: {
            help: "Number of cpus to use for this task. Default is 4.",
            type: "Int",
            category: "input_optional"
        }
        monitoring_script: {
            help: "UG resource monitoring script.",
            type: "File",
            category: "input_required"
        }
    }
    command <<<
        bash ~{monitoring_script} | tee monitoring.log >&2 &
        set -xeo pipefail

        # Chain with temp BCF to avoid one long pipeline (ARG_MAX). Each step is a short command.
        TEMP_BCF="filter_temp.bcf"
        TEMP_BCF2="filter_temp2.bcf"

        bcftools view --threads ~{cpus} ~{bcftools_extra_args} ~{input_vcf} -Ou -o "$TEMP_BCF"

        INCLUDE_REGIONS=(~{sep=" " include_regions})
        for f in "${INCLUDE_REGIONS[@]}"; do
            bcftools view --threads ~{cpus} "$TEMP_BCF" -T "$f" -Ou -o "$TEMP_BCF2"
            mv "$TEMP_BCF2" "$TEMP_BCF"
        done

        EXCLUDE_REGIONS=(~{sep=" " exclude_regions})
        for f in "${EXCLUDE_REGIONS[@]}"; do
            bcftools view --threads ~{cpus} "$TEMP_BCF" -T ^"$f" -Ou -o "$TEMP_BCF2"
            mv "$TEMP_BCF2" "$TEMP_BCF"
        done

        bcftools view --threads ~{cpus} "$TEMP_BCF" -Oz -o ~{output_vcf_filename}
        rm -f "$TEMP_BCF"
        bcftools index -t ~{output_vcf_filename}
    >>>
    output {
        File monitoring_log = "monitoring.log"
        File output_vcf = "~{output_vcf_filename}"
        File output_vcf_index = "~{output_vcf_filename}.tbi"
    }
    runtime {
        memory: "~{memory_gb} GB"
        disks: "local-disk " + disk_size + " HDD"
        docker: docker
        modules: "~{modules}"
        cpu: "~{cpus}"
        preemptible: preemptible_tries
    }
}


task ExtractSorterStatsMetrics {
    input{
      Array[File] sorter_json_stats_files
      String docker
      Int preemptible_tries
      File monitoring_script
    }
    String mean_coverage_output_file = "mean_coverage.txt"
    String total_aligned_bases_output_file = "total_aligned_bases.txt"
    command <<<
        set -eox pipefail
        bash ~{monitoring_script} | tee monitoring.log >&2 &

        # Initialize sums
        TOTAL_COVERAGE_SUM=0.0
        TOTAL_ALIGNED_BASES=0

        # Process each file
        for stats_file in ~{sep=" " sorter_json_stats_files}; do
            echo "Processing file: $stats_file"
            
            # Extract mean_coverage from this file
            MEAN_COV_TMP=$(mktemp)
            sorter_stats_to_mean_coverage \
                --sorter-stats-json "$stats_file" \
                --output-file "$MEAN_COV_TMP"
            MEAN_COV=$(cat "$MEAN_COV_TMP")
            rm "$MEAN_COV_TMP"
            
            # Extract total_aligned_bases from this file using jq
            TOTAL_BASES=$(jq -re '.total_aligned_bases // .total_bases // error("missing total_aligned_bases and total_bases")' "$stats_file")
            
            echo "File: $stats_file - mean_coverage: $MEAN_COV, total_aligned_bases: $TOTAL_BASES"
            
            # Aggregate mean_coverage and total_aligned_bases
            TOTAL_COVERAGE_SUM=$(awk -v current="$TOTAL_COVERAGE_SUM" -v new="$MEAN_COV" 'BEGIN{printf "%.12f", current + new}')
            TOTAL_ALIGNED_BASES=$((TOTAL_ALIGNED_BASES + TOTAL_BASES))
        done

        echo "Final mean_coverage (sum): $TOTAL_COVERAGE_SUM"
        echo "Final total_aligned_bases (sum): $TOTAL_ALIGNED_BASES"
        
        # Write outputs
        echo "$TOTAL_COVERAGE_SUM" > "~{mean_coverage_output_file}"
        echo "$TOTAL_ALIGNED_BASES" > "~{total_aligned_bases_output_file}"

    >>>
    runtime {
        preemptible: preemptible_tries
        memory: "2 GB"
        docker: docker
        cpu: "1"
    }
    output {
        Float mean_coverage = read_float("~{mean_coverage_output_file}")
        String total_aligned_bases = read_string("~{total_aligned_bases_output_file}")
        File monitoring_log = "monitoring.log"
    }
  }


task CopyFiles {
    input {
        Array[File] input_files
        String docker
    }
    command <<<
    >>>
    runtime {
        docker: docker
        preemptible: 1
        memory: "2 GB"
        cpu: "1"
        disks: "local-disk " +ceil(2*size(input_files,"GB") + 1) + " HDD"
        noAddress: true
    }
    output {
        Array[File] output_files = input_files
    }
}

# creates a bed file from a VCF file and expands if needed
task VcfToIntervalListAndBed {
    input {
        File monitoring_script
        File input_vcf
        Int bedtools_expand
        File reference_dict
        File reference_index
        String base_file_name
        String docker
        String modules = "gatk/4.6.2.0 bedtools/2.27"
        Int disk_size = ceil(2*size(input_vcf, "GB")) + 20
        Int preemptible_tries
        Boolean no_address
    }
    command <<< 
        set -xeo pipefail
        bash ~{monitoring_script} | tee monitoring.log >&2 &

        gatk VcfToIntervalList \
            I=~{input_vcf} \
            O=step1.interval_list 

        gatk IntervalListToBed \
            I=step1.interval_list \
            O=step2.bed
        awk 'BEGIN {FS=OFS="\t"} {print $1, $2}' ~{reference_index} > genome_file.txt
        bedtools slop -i step2.bed -g genome_file.txt -b ~{bedtools_expand} | bedtools merge -i - > ~{base_file_name}.bed
        gatk BedToIntervalList \
            I=~{base_file_name}.bed \
            O=~{base_file_name}.interval_list \
            SD=~{reference_dict}
    >>>

    runtime {
        memory: "2 GB"
        disks: "local-disk " + disk_size + " HDD"
        docker: docker
        modules: "~{modules}"
        preemptible: preemptible_tries
        noAddress: no_address
    }

    output {
        File interval_list = "~{base_file_name}.interval_list"
        File bed = "~{base_file_name}.bed"
        File monitoring_log = "monitoring.log"
    }
}

# creates a bed file from a VCF file and expands if needed
task BedToIntervalList {
    input {
        File monitoring_script
        File input_file
        File reference_dict
        String base_file_name
        String docker
        String modules = "gatk/4.6.2.0"
        Int disk_size = ceil(2*size(input_file, "GB")) + 5
        Int preemptible_tries
        Boolean no_address
    }

    command <<< 
        set -xeo pipefail
        bash ~{monitoring_script} | tee monitoring.log >&2 &

        gatk BedToIntervalList \
            I=~{input_file} \
            O=~{base_file_name}.interval_list \
            SD=~{reference_dict}
    >>>

    runtime {
        memory: "2 GB"
        disks: "local-disk " + disk_size + " HDD"
        docker: docker
        modules: "~{modules}"
        preemptible: preemptible_tries
        noAddress: no_address
    }

    output {
        File interval_list = "~{base_file_name}.interval_list"
        File monitoring_log = "monitoring.log"
    }
}

task ComputeMd5 {
    input {
        File input_file
        String docker
    }
    Int disk_size = ceil(size(input_file, "GB")) + 1
    String out_file = basename(input_file) + ".checksum.md5"
    command {
        md5sum "~{input_file}" > "~{out_file}"
    }

    output {
        File checksum = "~{out_file}"
    }

    runtime {
        docker: docker
        memory: "2 GB"
        disks: "local-disk " + disk_size + " HDD"
    }
}

task MergeMd5sToJson {
    parameter_meta {
        output_json: {
            help: "Output JSON file name containing the md5 checksums.",
            type: "String",
            category: "input_required"
        }
    }
    input {
        Array[File] md5_files
        String output_json = "md5_checksums.json"
        String docker
    }
    Int disk_size = ceil(size(md5_files, "GB")) + 1
    command <<<
        ls ~{sep=' ' md5_files} > md5_files.txt
        python <<CODE
import json
import os
md5_dict = {}
with open("md5_files.txt") as f:
    for line in f:
        fname = line.strip()
        if not fname:
            continue
        with open(fname) as fh:
            line = fh.read().strip()
            if line:
                md5, filename = line.split()
                md5_dict[os.path.basename(filename)] = md5
with open("~{output_json}", "w") as out_fh:
    json.dump(md5_dict, out_fh, indent=2)
CODE
    >>>
    output {
        File md5_json = output_json
    }
    runtime {
        docker: docker
        memory: "2 GB"
        disks: "local-disk " + disk_size + " HDD"
    }
}

task ConcatFiles{
    input{
        Array[File] files
        String out_file_name
        String docker
    }
    Int disk_size = ceil(2 * size(files,"GB") + 2)
    command <<<
        cat ~{sep=" " files} > ~{out_file_name}
    >>>

    runtime {
        disks: "local-disk " + ceil(disk_size) + " HDD"
        docker: docker
        cpu:1
    }
    output{
        File out_merged_file = "~{out_file_name}"
    }
}

# Calculate median coverage across genomic regions using samtools bedcov.
# Given multiple cram files, sum up their coverages.
# Handles both AWS and non-AWS cloud providers with different optimization strategies. 
task CalculateCoverage {

  input {
    File ref
    File ref_index
    File ref_dict
    Array[File] crams
    Array[File] cram_indices
    File quick_coverage_bed
    Int threads = 2
    Int jobMemory = 4
    String modules = "gatk/4.6.2.0 samtools/1.14"
    File monitoring_script
  }

  Int disk_size = ceil(1.5 * size(crams, "GB") + 20)

  parameter_meta {
    crams: {
        localization_optional: true
    }
  }

  command <<<
    set -xeo pipefail
    bash ~{monitoring_script} | tee monitoring.log >&2 &

    # Function to calculate median from coverage values
    # Sums coverage across all CRAM files (columns 4+) then calculates median
    calculate_median() {
      awk '{
        # Sum coverage from all files (columns 4 onwards)
        total_cov = 0;
        for(i=4; i<=NF; i++) total_cov += $i;
        if(total_cov > 0) print total_cov;
      }' | sort -n | awk 'BEGIN{c=0} {a[c++]=$1} END{if(c==0) print 0; else if(c%2) print a[int(c/2)]; else print (a[int(c/2)-1]+a[int(c/2)])/2}'
    }

    # Convert BED to interval list for GATK PrintReads
    gatk BedToIntervalList -I ~{quick_coverage_bed} -O coverage_regions.interval_list -SD ~{ref_dict} 2>&1

    # Extract only the coverage estimation regions
    gatk --java-options "-Xms1G" PrintReads \
        -I ~{sep=' -I ' crams} \
        -L coverage_regions.interval_list \
        -R ~{ref} \
        -O /dev/stdout | \
        samtools view -b -o coverage.bam -
    samtools index coverage.bam

    # Calculate median coverage
    median_cov=$(samtools bedcov ~{quick_coverage_bed} coverage.bam --reference ~{ref} | calculate_median)

    echo "Calculated median coverage: $median_cov"
    printf "%.0f" "$median_cov" > median_coverage.txt
  >>>

  runtime {
    memory: "~{jobMemory} GB"
    cpu: "~{threads}"
    modules: "~{modules}"
  }

  output {
    File monitoring_log = "monitoring.log"
    Int median_coverage = read_int("median_coverage.txt")
  }
}
